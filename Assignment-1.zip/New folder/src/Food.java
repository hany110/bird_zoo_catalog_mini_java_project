/*
* Different food types eaten by birds
 */
public enum Food {
    BERRIES, SEEDS, FRUIT, INSECTS, OTHER_BIRDS, EGGS, SMALL_MAMMALS, FISH,
    BUDS, LARVAE, AQUATIC_INVERTEBRATES, NUTS, VEGETATION
}
